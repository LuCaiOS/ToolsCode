//
//  FTCBufferSlider.h
//  WisdomWindow
//
//  Created by bluevision on 16/6/7.
//  Copyright (c) 2015年 逯常松. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASValueTrackingSlider.h"

@interface LCSBufferSlider : ASValueTrackingSlider

typedef void(^ConntionLockWaitFinishCallBack)(BOOL success);

@property (nonatomic ,assign) CGFloat totalSeconds;

@property (nonatomic, strong) UIImage *bufferMaxImage;//动的图片

@property (nonatomic, strong) UIImage *bufferMinImage;//动的图片

@property (nonatomic, strong) UIImage *thumbImage;//滑块图片


@property (nonatomic ,assign) BOOL  cancel;

- (void)startAnimation;

- (void)pauceAnimation;

- (void)setAnimationStop;

- (void)addConditionWaitFinishCallBack:(ConntionLockWaitFinishCallBack)condtionFinishCallBack;

@property (nonatomic ,weak) UIViewController *controller;

@end
