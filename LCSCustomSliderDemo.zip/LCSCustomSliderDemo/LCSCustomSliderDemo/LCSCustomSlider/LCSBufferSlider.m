//
//  FTCBufferSlider.m
//  WisdomWindow
//
//  Created by bluevision on 16/6/7.
//  Copyright (c) 2015年 逯常松. All rights reserved.
//

static int i = 0;


#import "LCSBufferSlider.h"

#import "UIImage+LCSExtension.h"

#import "AppDelegate.h"
@interface LCSBufferSlider()

@property (nonatomic ,assign)  BOOL isAnimation;

@property (nonatomic ,assign) CGFloat   originalValue;

@property (nonatomic ,weak) UIImageView *bufferImageView;

/**
 *  时钟动画对象
 */
@property (nonatomic ,strong) NSTimer *displayLink;


@property (nonatomic ,assign) CGFloat bufferValue;

@property (nonatomic ,strong) NSCondition *windowCondition;

@property (nonatomic ,strong) ConntionLockWaitFinishCallBack conditionWaitFinishCallBack;

@end
@implementation LCSBufferSlider


- (void)reset{
    
    self.isAnimation = NO;
    
    self.bufferImageView.image = nil;
    self.bufferImageView.frame = CGRectZero;
    [self pauceTimer];
    
    [self.windowCondition lock];
    [self.windowCondition signal];
    [self.windowCondition unlock];
}

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{
    
    if (self.isAnimation) {
        return NO;
    }
    
    BOOL is =  [super beginTrackingWithTouch:touch withEvent:event];
    self.originalValue = self.value;
    self.bufferValue = self.value;
    [self reset];
    
    return  is;
}

- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{
    
    BOOL is = [super continueTrackingWithTouch:touch withEvent:event];

    CGFloat marginValue = self.value -self.originalValue;
    
    double totalWidth = [self totalWidth];
    
    CGFloat thubWidth = [self thubWidth];

    CGFloat bufferWidth = totalWidth *fabs(marginValue);
    
    if (marginValue <0) {
    //如果现在值比原始值值小的话...说明向左
        self.bufferImageView.image = [[UIImage imageNamed:@"window_slider_buffer_red"] strechImage];
        //向左(宽度稍微剪去了滑块的4分之一是防治滑块有空白像素，这个自己调节)
     self.bufferImageView.frame = CGRectMake(self.value *totalWidth+thubWidth-thubWidth/4, 0, bufferWidth, self.bounds.size.height);
        
        
    }else{
        
        self.bufferImageView.image = [[UIImage imageNamed:@"window_slider_buffer_blue"] strechImage];
        //向右...(宽度稍微加上了滑块的4分之一是防治滑块有空白像素，这个自己调节)
        self.bufferImageView.frame = CGRectMake(self.originalValue *totalWidth, 0, bufferWidth+thubWidth/4, self.bounds.size.height);
    }
    
    return  is;
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{

    NSLog(@"endTrackingWithTouch isTraking = %d",self.isTracking);
    [super endTrackingWithTouch:touch withEvent:event];
}

- (void)cancelTrackingWithEvent:(UIEvent *)event{

    NSLog(@"cancelTrackingWithEven");
    [super cancelTrackingWithEvent:event];
    [self reset];
}

- (UIImageView *)bufferImageView{

    if (_bufferImageView) {
        return _bufferImageView;
    }
    
    UIImageView *bufferImageView = [[UIImageView alloc] init];
    bufferImageView.userInteractionEnabled = NO;
    [self addSubview:bufferImageView];
    _bufferImageView = bufferImageView;
    return bufferImageView;
}


- (NSTimer *)displayLink
{
    if (_displayLink == nil) {

        CGFloat second = [self perMoveSecond];
        NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:second target:self selector:@selector(action:) userInfo:nil repeats:YES];
        _displayLink = timer;
        [self pauceTimer];
    }
    return _displayLink;
}

#pragma mark -动画相关
- (void)pauceAnimation{
    
    [self reset];
}

/**
 *  动画开始
 */
- (void)startAnimation
{
    
    self.isAnimation = YES;
    
    [self startTimer];
    i = 0;
    
    dispatch_async( dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
       
        [self.windowCondition lock];
        BOOL success = [self.windowCondition waitUntilDate:[NSDate dateWithTimeInterval:([self totalSeconds]+2) sinceDate:[NSDate date]]];
        [self.windowCondition unlock];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self reset];
            
            if (self.conditionWaitFinishCallBack) {
                self.conditionWaitFinishCallBack(success);
            }
        });
    });
}


- (void)addConditionWaitFinishCallBack:(ConntionLockWaitFinishCallBack)condtionFinishCallBack{

    self.conditionWaitFinishCallBack = condtionFinishCallBack;
}

- (void)setAnimationStop{
    
    [self.windowCondition lock];
    [self.windowCondition signal];
    [self.windowCondition unlock];
    
    self.isAnimation = NO;
    
    if (self.displayLink) {

        [self pauceTimer];
        [self.displayLink invalidate];
        self.displayLink = nil;
        NSLog(@"关闭时钟动画...");
    }
}

- (void)pauceTimer{
    
    [self.displayLink setFireDate:[NSDate distantFuture]];
}

- (void)startTimer{

    [self.displayLink setFireDate:[NSDate distantPast]];
}

/**
 *  一秒钟刷新60次
 *
 */
- (void)action:(NSTimer *)displayLink
{
    //如果每秒刷新的话。。。
    //如果35秒走完的话。。。那么增加1/35....
    
    //每次移动需要多少时间
    CGFloat perMoveSecond = [self perMoveSecond];
    
    //每次移动多少值
    CGFloat perMoveValue  = perMoveSecond/[self totalSeconds];
    
    if (self.value > self.originalValue) {
        
        CGFloat bufferValue = self.bufferValue + perMoveValue;
        if (bufferValue >= self.value) {
            bufferValue = self.value;
            [self setAnimationStop];
        }
        self.bufferValue = bufferValue;
        
    }else{
        
        CGFloat bufferValue = self.bufferValue - perMoveValue;
        if (bufferValue <= self.value) {
            bufferValue = self.value;
            [self setAnimationStop];
        }
        self.bufferValue = bufferValue;
    }
}

- (void)setBufferValue:(CGFloat)bufferValue{
    
    _bufferValue = bufferValue;
    CGFloat totalWidth = [self totalWidth];
    CGFloat thubWidth = [self thubWidth];
    CGFloat marginValue = self.value -bufferValue;
    
    if (self.value > self.originalValue) {
        //向右
        self.bufferImageView.frame = CGRectMake(bufferValue *totalWidth, 0, fabs(marginValue)*totalWidth+thubWidth/4, self.bounds.size.height);
    }else{
        //向左
        self.bufferImageView.frame = CGRectMake(self.value *totalWidth+thubWidth-thubWidth/4, 0, fabs(marginValue) *totalWidth, self.bounds.size.height);
    }
}

- (CGFloat)totalWidth{
    
    return self.bounds.size.width - [self thubWidth];
}

- (CGFloat)thubWidth{

   UIImage *thumb = _thumbImage;

    if(thumb.size.width>0){
        return thumb.size.width;
    }
    return 30;
}

- (CGFloat)totalSeconds{
    
    if(_totalSeconds>0){
        return _totalSeconds;
    }
    return 18.f;
}


//每次移动需要多少秒
- (CGFloat)perMoveSecond{
    
    return 1/20.f;
}


- (NSCondition *)windowCondition{
    
    if (_windowCondition) {
        return _windowCondition;
    }
    
    NSCondition *condition = [[NSCondition alloc] init];
    self.windowCondition  = condition;
    return condition;
}


@end
