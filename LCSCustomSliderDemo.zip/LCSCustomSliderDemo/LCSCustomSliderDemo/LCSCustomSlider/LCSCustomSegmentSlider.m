//
//  LCSCustomSlider.m
//  CustomSlider
//
//  Created by 逯常松 on 16/6/7.
//  Copyright © 2016年 逯常松. All rights reserved.
//

#import "LCSCustomSegmentSlider.h"
#import "UIImage+LCSExtension.h"

@interface LCSCustomSegmentSlider()

@property (nonatomic ,weak)  UIImageView       *minImageView;
@property (nonatomic ,weak)  UIImageView       *maxImageView;

@property (nonatomic ,strong) NSMutableDictionary *thumbDict;
@property (nonatomic ,strong) NSMutableDictionary *minDict;
@property (nonatomic ,strong) NSMutableDictionary *maxDict;


@end


@implementation LCSCustomSegmentSlider

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{
    
    CGPoint point  = [touch locationInView:self];
    if (!CGRectContainsPoint(self.thumImageView.frame, point)) {
        return NO;
    }
    
    return  [super beginTrackingWithTouch:touch withEvent:event];
}


- (void)setBufferValueWithPoint:(CGPoint)point{
    
    CGFloat thumbImageWidth = [self thumbImageSize].width;
    CGFloat thumbImageX = point.x-thumbImageWidth/2.f;

    if (point.x <0) {
        thumbImageX = 0;
    }
    
    if (point.x > [self totalWidth]) {
        thumbImageX = thumbImageX;
    }
    self.value = [self valueFromOriginX:thumbImageX];
    
}

- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{
    
    //    NSLog(@"continueTrackingWithTouch");
    CGPoint point  = [touch locationInView:self];
    [self setBufferValueWithPoint:point];
    
    if (self.continuous) {
        
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
    
    return  [super continueTrackingWithTouch:touch withEvent:event];
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event{
    
    //    NSLog(@"endTrackingWithTouch");
    CGPoint point  = [touch locationInView:self];
    [self setBufferValueWithPoint:point];
    
    if (!self.continuous) {
        
        [self sendActionsForControlEvents:UIControlEventValueChanged];
    }
    [super endTrackingWithTouch:touch withEvent:event];
}

- (void)cancelTrackingWithEvent:(UIEvent *)event{
    
    NSLog(@"cancelTrackingWithEvent");
    
    [super cancelTrackingWithEvent:event];
}


- (instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.continuous  = YES;
        self.userInteractionEnabled = YES;
        self.backgroundColor = [UIColor clearColor];
        
        self.minimumValue = 0;
        self.maximumValue = 1;
        self.value = 0;
        
        UIImageView  *maxImageView = [[UIImageView alloc] init];
        [self addSubview:maxImageView];
        _maxImageView = maxImageView;
        
        UIImageView *minImageView = [[UIImageView alloc] init];
        [self addSubview:minImageView];
        _minImageView = minImageView;
        
        UIImageView *thumImageView = [[UIImageView alloc]  init];
        [self addSubview:thumImageView];
        _thumImageView = thumImageView;
    }
    return self;
}

- (CGFloat)totalWidth{
    
    CGSize thumbSize = [self thumbImageSize];
    return self.bounds.size.width - thumbSize.width;
}

- (CGFloat)valueFromOriginX:(CGFloat)originX{
    
    
    CGFloat totalW = [self totalWidth];
    
    CGFloat value = originX/totalW;
    
    if (value <= self.minimumValue) {
        
        value = self.minimumValue;
    }
    if (value >= self.maximumValue) {
        
        value = self.maximumValue;
    }
    return  value;

}

- (CGFloat)thumbOriginXFromValue:(CGFloat)value{
    
    CGFloat totalW = [self totalWidth];
    CGFloat originX = totalW *value;
    
    return originX;
}

- (void)setValue:(float)value{
    
    if (value != _value) {
        
        _value = value;
        
        
        [self setNeedsLayout];
        [self layoutIfNeeded];
        
    }
}

- (void)setValue:(float)value animated:(BOOL)animated{
    
    self.value = value;
}

- (void)setMinimumValueImage:(UIImage *)minimumValueImage{
    
    [self setMinimumTrackImage:minimumValueImage forState:UIControlStateNormal];
    
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)setMaximumValueImage:(UIImage *)maximumValueImage{
    
    [self setMaximumTrackImage:maximumValueImage forState:UIControlStateNormal];
    
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)setMinimumTrackImage:(nullable UIImage *)image forState:(UIControlState)state{
    
    [self.minDict setObject:image forKey:[NSNumber numberWithInt:state]];
    
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)setMaximumTrackImage:(nullable UIImage *)image forState:(UIControlState)state{
    
    [self.maxDict setObject:image forKey:[NSNumber numberWithInt:state]];
    
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)setThumbImage:(nullable UIImage *)image forState:(UIControlState)state{
    
    if(!image){
        return;
    }
    [self.thumbDict setObject:image forKey:[NSNumber numberWithInt:state]];
    
    
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)layoutSubviews{
    
    [super layoutSubviews];
    
    NSNumber *nomalState = [NSNumber numberWithInt:UIControlStateNormal];
    
    NSDictionary *thumbDict = [NSDictionary dictionaryWithDictionary:self.thumbDict];
    UIImage *thubImage = thumbDict[nomalState];
    CGSize thubImageSize = thubImage.size;
    
    NSDictionary *minDict = [ NSDictionary dictionaryWithDictionary:self.minDict];
    UIImage *minImage =  minDict[nomalState];
    
    
    NSDictionary *maxDict = [NSDictionary dictionaryWithDictionary:self.maxDict];
    UIImage *maxImage = maxDict[nomalState];
    
    
    self.thumImageView.image = thubImage;
    self.maxImageView.image = maxImage;
    
    CGFloat value = self.value;
    CGFloat thumbImageX = [self thumbOriginXFromValue:value];
    
    self.thumImageView.frame = CGRectMake(thumbImageX, self.bounds.size.height/2.f -thubImageSize.height/2.f, thubImageSize.width, thubImageSize.height);
    
    self.maxImageView.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
    
    
    CGRect minRect = CGRectMake(0, 0, thumbImageX+thubImageSize.width/2.f, self.bounds.size.height);
    
    self.minImageView.frame = minRect;
    self.minImageView.image = [minImage clicpImageWithRect:minRect];
}


#pragma mark -

#pragma mark - Lazy Load
- (NSMutableDictionary *)thumbDict{
    
    if (_thumbDict) {
        return _thumbDict;
    }
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    _thumbDict = dict;
    return dict;
}

- (NSMutableDictionary *)minDict{
    
    if (_minDict) {
        return _minDict;
    }
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    _minDict = dict;
    return dict;
}

- (NSMutableDictionary *)maxDict{
    
    if (_maxDict) {
        return _maxDict;
    }
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    _maxDict = dict;
    return dict;
}

- (CGSize)thumbImageSize{
    
    return [[self thumbImage] size];
}

- (UIImage *)thumbImage{
    
    NSNumber *nomal = [NSNumber numberWithInt:UIControlStateNormal];
    return self.thumbDict[nomal];
}

// lets a subclass lay out the track and thumb as needed
- (CGRect)minimumValueImageRectForBounds:(CGRect)bounds{
    
    return self.bounds;
}

- (CGRect)maximumValueImageRectForBounds:(CGRect)bounds{
    
    return self.bounds;
}

- (CGRect)trackRectForBounds:(CGRect)bounds{
    
    return self.bounds;
}

- (CGRect)thumbRectForBounds:(CGRect)bounds trackRect:(CGRect)rect value:(float)value{
    
    
    NSNumber *nomalState = [NSNumber numberWithInt:UIControlStateNormal];
    
    NSDictionary *thumbDict = [NSDictionary dictionaryWithDictionary:self.thumbDict];
    UIImage *thubImage = thumbDict[nomalState];
    CGSize thubImageSize = thubImage.size;
    
    
    CGFloat thumbImageX = [self thumbOriginXFromValue:value];
    
    CGRect thumbRect = CGRectMake(thumbImageX, self.bounds.size.height/2.f -thubImageSize.height/2.f, thubImageSize.width, thubImageSize.height);
    
    return thumbRect;
}

@end
