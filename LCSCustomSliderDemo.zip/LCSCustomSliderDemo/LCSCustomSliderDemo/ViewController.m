//
//  ViewController.m
//  LCSCustomSliderDemo
//
//  Created by 逯常松 on 16/6/17.
//  Copyright © 2016年 逯常松. All rights reserved.
//

#import "ViewController.h"

#import "LCSBufferSlider.h"

@interface ViewController ()<ASValueTrackingSliderDataSource>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    
    UIImage *sliderImage = [UIImage imageNamed:@"window_detail_slider_max"];

    LCSBufferSlider *customSlider = [[LCSBufferSlider alloc] init];
    
    customSlider.frame = CGRectMake(70, 100, sliderImage.size.width, sliderImage.size.height);
    
    customSlider.dataSource = self;//设置代理，上边弹框代理
    customSlider.totalSeconds = 5;//设置全程需要的时间
    
    //765 × 100 pixels
    customSlider.continuous = NO;//千万别忘记这个

    
    [customSlider setThumbImage:[UIImage imageNamed:@"window_detail_slider_thumb"] forState:UIControlStateNormal];
    [customSlider setMinimumTrackImage:[UIImage imageNamed:@"window_detail_slider_max"] forState:UIControlStateNormal];
    
    [customSlider setMaximumTrackImage:[UIImage imageNamed:@"window_detail_slider_min"] forState:UIControlStateNormal];
    
    
    [self.view addSubview:customSlider];
    
    [customSlider addTarget:self action:@selector(windowSliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)windowSliderValueChanged:(UISlider *)slider{

    LCSBufferSlider *customSlider = (LCSBufferSlider *)slider;
    [customSlider startAnimation];//开始动画

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [customSlider pauceAnimation];//3秒后停止动画--->可以设置动画结束，滑块回弹效果
        
    });
    
}


//弹框显示文字
- (NSString *)slider:(ASValueTrackingSlider *)slider stringForValue:(float)value{
    
    return [NSString stringWithFormat:@"%.0f %%",value *100];
        
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
